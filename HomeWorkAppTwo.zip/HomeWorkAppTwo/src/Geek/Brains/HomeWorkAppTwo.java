package Geek.Brains;

import java.util.Scanner;

public class HomeWorkAppTwo {

    public static void main(String[] args) {
        //** Написать метод, принимающий на вход два целых числа и проверяющий,
        // что их сумма лежит в пределах от 10 до 20 (включительно), если да – вернуть true,
        // в противном случае – false.

        //2. Написать метод, которому в качестве параметра передается целое число,
        // метод должен напечатать в консоль, положительное ли число передали или отрицательное.
        // Замечание: ноль считаем положительным числом.

        //3. Написать метод, которому в качестве параметра передается целое число.
        // Метод должен вернуть true, если число отрицательное,
        // и вернуть false если положительное.

        //4. Написать метод, которому в качестве аргументов передается строка и число,
        // метод должен отпечатать в консоль указанную строку,
        // указанное количество раз;

        //5. * Написать метод, который определяет,
        // является ли год високосным,
        // и возвращает boolean (високосный - true,
        // не високосный - false). Каждый 4-й год является високосным,
        // кроме каждого 100-го, при этом каждый 400-й – високосный.*/

        System.out.println(HomeworkOne(100, 10));
        HomeworkTwo(0);
        System.out.println(HomeworkThree(100));
        HomeworkFour("*", 30);
        System.out.println(HomeworkFive(2004));
    }

    static boolean HomeworkOne(int a, int b) {
        System.out.println("Задание номер 1:");
        if ((a + b) >= 10 && (a + b) <= 20) {
            return true;
        } else {
            return false;
        }
    }

    static void HomeworkTwo(int a) {
        System.out.println("Задание номер 2:");
        System.out.print("Число: [" + a);
        if (a >= 0) {

            System.out.println("] Положительное ");
        } else {
            System.out.println("] Отрицательное");
        }
    }

    static boolean HomeworkThree(int a) {
        System.out.println("Задание номер 3:");
        if (a >= 0) {
            return true;
        } else {
            return false;

        }
    }

    static void HomeworkFour(String Asterisk, int r) {
        System.out.println("Задание номер 4:");
        for (int i = 0; i <= r; i++) {
            System.out.print(Asterisk);
        }

    }

    static boolean HomeworkFive(int a) {
        System.out.println("");
        System.out.println("Задание номер 5:");
        if ((a % 400 == 0) | ((a % 100 != 0) & (a % 4 == 0))) {
            return true;
        } else {
            return false;
        }


    }
}

















